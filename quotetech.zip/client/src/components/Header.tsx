import { APP_LOGO, APP_TITLE } from "@/const";
import { Link } from "wouter";
import { Button } from "./ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

export default function Header() {
  const { isAuthenticated, logout } = useAuth();

  return (
    <header className="sticky top-0 z-50 bg-background border-b border-border shadow-sm">
      <div className="container flex items-center justify-between h-16">
        {/* Logo and Brand */}
        <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
          {APP_LOGO && (
            <img src={APP_LOGO} alt={APP_TITLE} className="h-8 w-8" />
          )}
          <span className="font-bold text-lg text-primary hidden sm:inline">
            {APP_TITLE}
          </span>
        </Link>

        {/* Navigation Links */}
        <nav className="hidden md:flex items-center gap-8">
          <Link href="/" className="text-foreground hover:text-accent transition-colors font-medium">
            Início
          </Link>
          <Link href="/about" className="text-foreground hover:text-accent transition-colors font-medium">
            Sobre Nós
          </Link>
          <Link href="/contact" className="text-foreground hover:text-accent transition-colors font-medium">
            Contato
          </Link>
        </nav>

        {/* Auth Buttons */}
        <div className="flex items-center gap-2">
          {isAuthenticated ? (
            <Button
              onClick={logout}
              variant="outline"
              size="sm"
            >
              Sair
            </Button>
          ) : (
            <Button
              asChild
              size="sm"
            >
              <a href={getLoginUrl()}>
                Entrar
              </a>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
