import { Keyboard, Zap, FileText } from "lucide-react";

export default function HowItWorks() {
  const steps = [
    {
      icon: Keyboard,
      title: "Digite o Modelo",
      description: "Insira o modelo ou número de série do seu notebook",
    },
    {
      icon: Zap,
      title: "Buscamos nos Fornecedores",
      description: "Nossa IA analisa fornecedores em tempo real",
    },
    {
      icon: FileText,
      title: "Receba a Cotação Completa",
      description: "Obtenha preços, mão de obra e links de compra",
    },
  ];

  return (
    <section className="py-16 bg-secondary/20">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4">
            Como Funciona
          </h2>
          <p className="text-muted-foreground text-lg">
            Três passos simples para obter suas cotações
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div
                key={index}
                className="flex flex-col items-center text-center p-6 rounded-lg bg-background border border-border hover-scale"
              >
                <div className="mb-4 p-3 bg-accent/10 rounded-full">
                  <Icon className="w-8 h-8 text-accent" />
                </div>
                <h3 className="text-xl font-semibold text-primary mb-2">
                  {step.title}
                </h3>
                <p className="text-muted-foreground">
                  {step.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
