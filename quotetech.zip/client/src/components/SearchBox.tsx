import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Search } from "lucide-react";

interface SearchBoxProps {
  onSearch: (query: string) => void;
  isLoading?: boolean;
}

export default function SearchBox({ onSearch, isLoading = false }: SearchBoxProps) {
  const [query, setQuery] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl mx-auto">
      <div className="flex gap-2">
        <Input
          type="text"
          placeholder="Digite o Modelo ou Serial Number (ex: Dell G15 5511)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          disabled={isLoading}
          className="flex-1 h-12 text-base"
        />
        <Button
          type="submit"
          disabled={isLoading || !query.trim()}
          className="bg-accent hover:bg-accent/90 text-accent-foreground h-12 px-8 font-semibold"
        >
          {isLoading ? (
            <>
              <span className="animate-spin mr-2">⏳</span>
              Buscando...
            </>
          ) : (
            <>
              <Search className="w-4 h-4 mr-2" />
              Buscar Cotação
            </>
          )}
        </Button>
      </div>
    </form>
  );
}
