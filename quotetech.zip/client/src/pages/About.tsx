import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function About() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1">
        <div className="container py-12">
          {/* Hero Section */}
          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6">
              Sobre a QuoteTech
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl">
              A QuoteTech é uma plataforma inovadora que revoluciona a forma como profissionais
              e empresas obtêm cotações de peças de notebook. Com tecnologia de IA avançada,
              fornecemos análises precisas e em tempo real.
            </p>
          </div>

          {/* Mission Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
            <div className="bg-card border border-border rounded-lg p-8">
              <h2 className="text-2xl font-bold text-primary mb-4">
                Nossa Missão
              </h2>
              <p className="text-muted-foreground leading-relaxed">
                Simplificar o processo de obtenção de cotações de peças de notebook,
                economizando tempo e dinheiro dos nossos clientes através de análise
                automática de fornecedores e preços em tempo real.
              </p>
            </div>

            <div className="bg-card border border-border rounded-lg p-8">
              <h2 className="text-2xl font-bold text-primary mb-4">
                Nossa Visão
              </h2>
              <p className="text-muted-foreground leading-relaxed">
                Ser a plataforma líder em cotações de peças de notebook na América Latina,
                oferecendo a melhor experiência do usuário e os dados mais precisos do mercado.
              </p>
            </div>
          </div>

          {/* Values Section */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-primary mb-8">
              Nossos Valores
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  title: "Precisão",
                  description: "Dados atualizados e verificados constantemente",
                },
                {
                  title: "Velocidade",
                  description: "Resultados em segundos, não em horas",
                },
                {
                  title: "Transparência",
                  description: "Informações claras e sem custos ocultos",
                },
              ].map((value, index) => (
                <div
                  key={index}
                  className="bg-card border border-border rounded-lg p-6 text-center hover-scale"
                >
                  <h3 className="text-xl font-semibold text-primary mb-2">
                    {value.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <div className="bg-primary text-primary-foreground rounded-lg p-12 text-center">
            <h2 className="text-3xl font-bold mb-4">
              Pronto para começar?
            </h2>
            <p className="text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
              Obtenha suas cotações de peças de notebook em segundos
            </p>
            <Link href="/">
              <Button
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                Buscar Cotação Agora
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
