import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail, Phone, MapPin } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement form submission
    alert("Mensagem enviada com sucesso! Entraremos em contato em breve.");
    setFormData({
      name: "",
      email: "",
      subject: "",
      message: "",
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1">
        <div className="container py-12">
          {/* Hero Section */}
          <div className="mb-12 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
              Entre em Contato
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Tem dúvidas ou sugestões? Adoraríamos ouvir de você!
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            {/* Contact Info Cards */}
            <div className="bg-card border border-border rounded-lg p-8 text-center hover-scale">
              <div className="mb-4 flex justify-center">
                <div className="p-3 bg-accent/10 rounded-full">
                  <Mail className="w-6 h-6 text-accent" />
                </div>
              </div>
              <h3 className="text-xl font-semibold text-primary mb-2">Email</h3>
              <p className="text-muted-foreground">
                info@quotetech.com
              </p>
            </div>

            <div className="bg-card border border-border rounded-lg p-8 text-center hover-scale">
              <div className="mb-4 flex justify-center">
                <div className="p-3 bg-accent/10 rounded-full">
                  <Phone className="w-6 h-6 text-accent" />
                </div>
              </div>
              <h3 className="text-xl font-semibold text-primary mb-2">Telefone</h3>
              <p className="text-muted-foreground">
                (11) 3000-0000
              </p>
            </div>

            <div className="bg-card border border-border rounded-lg p-8 text-center hover-scale">
              <div className="mb-4 flex justify-center">
                <div className="p-3 bg-accent/10 rounded-full">
                  <MapPin className="w-6 h-6 text-accent" />
                </div>
              </div>
              <h3 className="text-xl font-semibold text-primary mb-2">Endereço</h3>
              <p className="text-muted-foreground">
                São Paulo, SP - Brasil
              </p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="max-w-2xl mx-auto bg-card border border-border rounded-lg p-8">
            <h2 className="text-2xl font-bold text-primary mb-6">
              Envie uma Mensagem
            </h2>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Nome
                </label>
                <Input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Seu nome"
                  required
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Email
                </label>
                <Input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="seu@email.com"
                  required
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Assunto
                </label>
                <Input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder="Assunto da mensagem"
                  required
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Mensagem
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Sua mensagem aqui..."
                  required
                  rows={6}
                  className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
              >
                Enviar Mensagem
              </Button>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
