import { useState } from "react";
import { useLocation } from "wouter";
import SearchBox from "@/components/SearchBox";
import HowItWorks from "@/components/HowItWorks";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Home() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);

  // tRPC mutation for quotation search
  const quotationSearchMutation = trpc.quotation.search.useMutation({
    onSuccess: (data) => {
      console.log("Quotation search successful:", data);
      // Store the data in sessionStorage for the results page
      sessionStorage.setItem("quotationData", JSON.stringify(data));
      // Navigate to results page
      setLocation("/results");
    },
    onError: (error) => {
      console.error("Quotation search error:", error);
      toast.error(`Erro: ${error.message}`);
      setIsLoading(false);
    },
  });

  const handleSearch = async (query: string) => {
    if (!query.trim()) {
      toast.error("Digite um modelo ou S/N válido");
      return;
    }

    setIsLoading(true);
    try {
      // Call the tRPC mutation to search for quotation
      await quotationSearchMutation.mutateAsync({
        modeloOuSerialNumber: query,
      });
    } catch (error) {
      console.error("Search error:", error);
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 md:py-32 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
          <div className="container text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Cotações de Peças de Notebook em Segundos
            </h1>
            <p className="text-lg md:text-xl text-primary-foreground/90 mb-12 max-w-2xl mx-auto">
              Encontre os melhores preços de peças de notebook com análise automática de fornecedores
            </p>

            {/* Search Component */}
            <div className="mb-8">
              <SearchBox onSearch={handleSearch} isLoading={isLoading} />
            </div>

            {/* Loading message */}
            {isLoading && (
              <p className="text-primary-foreground/80 animate-pulse">
                Analisando seu notebook com IA... Isso pode levar alguns segundos.
              </p>
            )}
          </div>
        </section>

        {/* How It Works Section */}
        <HowItWorks />

        {/* Features Section */}
        <section className="py-16 bg-background">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: "Rápido", description: "Resultados em segundos" },
                { title: "Preciso", description: "Dados atualizados em tempo real" },
                { title: "Completo", description: "Análise de mão de obra incluída" },
                { title: "Confiável", description: "Fornecedores verificados" },
              ].map((feature, index) => (
                <div
                  key={index}
                  className="p-6 bg-card border border-border rounded-lg text-center hover-scale"
                >
                  <h3 className="font-semibold text-primary mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
