import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Download, Save, ExternalLink } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

interface SupplierLink {
  fornecedor: string;
  preco_medio: string;
  url_busca: string;
  disponibilidade: string;
}

interface Part {
  nome_peca: string;
  part_number: string;
  tipo: string;
  especificacao: string;
  preco_medio: string;
  links_fornecedores: SupplierLink[];
  imagem_peca?: string;
}

interface QuotationData {
  modelo_identificado: string;
  especificacoes_completas: {
    processador?: string;
    gpu?: string;
    ram?: string;
    armazenamento?: string;
    tela?: string;
    bateria?: string;
  };
  imagem_modelo_url: string;
  dificuldade_reparo: string;
  tempo_estimado: string;
  valor_mao_de_obra_sugerido: string;
  observacoes: string;
  pecas_encontradas: Part[];
}

export default function Results() {
  const [, setLocation] = useLocation();
  const [data, setData] = useState<QuotationData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    const storedData = sessionStorage.getItem("quotationData");
    if (storedData) {
      try {
        const parsedData = JSON.parse(storedData);
        setData(parsedData);
      } catch (error) {
        console.error("Failed to parse quotation data:", error);
        toast.error("Erro ao carregar dados da cotação");
      }
    }
    setIsLoading(false);
  }, []);

  const handleExportPDF = () => {
    toast.info("Funcionalidade de exportação em PDF será implementada em breve!");
  };

  const handleSaveQuotation = () => {
    if (!isAuthenticated) {
      toast.error("Você precisa estar logado para salvar cotações!");
      return;
    }
    toast.success("Cotação salva com sucesso!");
  };

  const handleOpenLink = (url: string) => {
    if (url && url.startsWith("http")) {
      window.open(url, "_blank", "noopener,noreferrer");
    } else {
      toast.error("Link inválido");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin mb-4">⏳</div>
            <p className="text-muted-foreground">Carregando cotação...</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <p className="text-muted-foreground mb-4">Nenhuma cotação encontrada</p>
            <Button onClick={() => setLocation("/")} variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para Busca
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const specs = data.especificacoes_completas || {};

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1">
        <div className="container py-8">
          <Button
            onClick={() => setLocation("/")}
            variant="outline"
            size="sm"
            className="mb-8"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para Busca
          </Button>

          <div className="bg-card border border-border rounded-lg p-8 mb-8 fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <img
                  src={data.imagem_modelo_url}
                  alt={data.modelo_identificado}
                  className="w-full h-64 object-cover rounded-lg"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = `https://via.placeholder.com/400x300?text=${encodeURIComponent(
                      data.modelo_identificado
                    )}`;
                  }}
                />
              </div>

              <div>
                <h1 className="text-3xl font-bold text-primary mb-4">
                  {data.modelo_identificado}
                </h1>

                {specs && Object.keys(specs).length > 0 ? (
                  <div className="bg-secondary/20 rounded-lg p-4 mb-6 text-sm space-y-2">
                    {specs.processador && (
                      <div>
                        <span className="font-medium text-foreground">Processador:</span>
                        <span className="ml-2 text-muted-foreground">{specs.processador}</span>
                      </div>
                    )}
                    {specs.gpu && (
                      <div>
                        <span className="font-medium text-foreground">GPU:</span>
                        <span className="ml-2 text-muted-foreground">{specs.gpu}</span>
                      </div>
                    )}
                    {specs.ram && (
                      <div>
                        <span className="font-medium text-foreground">Memória:</span>
                        <span className="ml-2 text-muted-foreground">{specs.ram}</span>
                      </div>
                    )}
                    {specs.armazenamento && (
                      <div>
                        <span className="font-medium text-foreground">Armazenamento:</span>
                        <span className="ml-2 text-muted-foreground">{specs.armazenamento}</span>
                      </div>
                    )}
                    {specs.tela && (
                      <div>
                        <span className="font-medium text-foreground">Tela:</span>
                        <span className="ml-2 text-muted-foreground">{specs.tela}</span>
                      </div>
                    )}
                    {specs.bateria && (
                      <div>
                        <span className="font-medium text-foreground">Bateria:</span>
                        <span className="ml-2 text-muted-foreground">{specs.bateria}</span>
                      </div>
                    )}
                  </div>
                ) : null}

                <div className="bg-secondary/20 rounded-lg p-6 mb-6">
                  <h2 className="text-xl font-semibold text-primary mb-4">
                    Análise de Mão de Obra
                  </h2>
                  <div className="space-y-3">
                    <div>
                      <span className="font-medium text-foreground">
                        Nível de Dificuldade:
                      </span>
                      <span className="ml-2 text-muted-foreground">
                        {data.dificuldade_reparo}
                      </span>
                    </div>

                    <div>
                      <span className="font-medium text-foreground">
                        Tempo Estimado:
                      </span>
                      <span className="ml-2 text-muted-foreground">
                        {data.tempo_estimado}
                      </span>
                    </div>

                    <div>
                      <span className="font-medium text-foreground">
                        Valor Sugerido de Mão de Obra:
                      </span>
                      <span className="ml-2 text-accent font-semibold">
                        {data.valor_mao_de_obra_sugerido}
                      </span>
                    </div>

                    <div className="pt-3 border-t border-border">
                      <p className="text-sm text-muted-foreground">
                        <strong>Observações:</strong> {data.observacoes}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={handleExportPDF}
                    variant="outline"
                    className="flex-1"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Exportar PDF
                  </Button>
                  {isAuthenticated && (
                    <Button
                      onClick={handleSaveQuotation}
                      className="flex-1 bg-accent hover:bg-accent/90"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Salvar Cotação
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="fade-in">
            <h2 className="text-2xl font-bold text-primary mb-6">
              Cotação de Peças
            </h2>

            {data.pecas_encontradas.length === 0 ? (
              <div className="bg-card border border-border rounded-lg p-8 text-center">
                <p className="text-muted-foreground">
                  Nenhuma peça encontrada para este notebook.
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {data.pecas_encontradas.map((peca, index) => (
                  <div
                    key={index}
                    className="bg-card border border-border rounded-lg p-6 hover-scale"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {peca.imagem_peca && (
                        <div className="flex items-center justify-center">
                          <img
                            src={peca.imagem_peca}
                            alt={peca.nome_peca}
                            className="w-full h-48 object-cover rounded-lg"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = `https://via.placeholder.com/200x150?text=${encodeURIComponent(
                                peca.nome_peca
                              )}`;
                            }}
                          />
                        </div>
                      )}

                      <div>
                        <h3 className="text-xl font-semibold text-primary mb-2">
                          {peca.nome_peca}
                        </h3>

                        <p className="text-sm text-muted-foreground mb-2">
                          Tipo: {peca.tipo}
                        </p>

                        <p className="text-sm text-muted-foreground mb-4">
                          Part Number: {peca.part_number}
                        </p>

                        <p className="text-sm text-muted-foreground mb-4">
                          Especificação: {peca.especificacao}
                        </p>

                        <div className="bg-accent/10 rounded-lg p-4">
                          <p className="text-sm text-muted-foreground">
                            Preço Médio
                          </p>
                          <p className="text-2xl font-bold text-accent">
                            {peca.preco_medio}
                          </p>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold text-foreground mb-4">
                          Onde Comprar
                        </h4>
                        <div className="space-y-3 max-h-96 overflow-y-auto">
                          {peca.links_fornecedores.length === 0 ? (
                            <p className="text-sm text-muted-foreground">
                              Buscando fornecedores...
                            </p>
                          ) : (
                            peca.links_fornecedores.map((link, linkIndex) => (
                              <button
                                key={linkIndex}
                                onClick={() => handleOpenLink(link.url_busca)}
                                className="w-full flex items-center justify-between p-3 bg-secondary/20 rounded-lg hover:bg-secondary/40 transition-colors text-left"
                              >
                                <div className="flex-1">
                                  <p className="font-medium text-foreground">
                                    {link.fornecedor}
                                  </p>
                                  <p className="text-sm text-accent font-semibold">
                                    {link.preco_medio}
                                  </p>
                                  <p className="text-xs text-muted-foreground mt-1">
                                    {link.disponibilidade}
                                  </p>
                                </div>
                                <ExternalLink className="w-4 h-4 text-accent flex-shrink-0 ml-2" />
                              </button>
                            ))
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
