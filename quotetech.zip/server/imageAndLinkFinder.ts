import { invokeLLM } from "./_core/llm";

interface SearchLink {
  fornecedor: string;
  preco_medio: string;
  url_busca: string;
  disponibilidade: string;
}

/**
 * Busca imagens reais de notebooks e peças usando busca de imagens via IA
 */
export async function findNotebookAndPieceImages(
  notebookModel: string,
  piecesNames: string[]
): Promise<{
  notebook_image: string;
  piece_images: Record<string, string>;
}> {
  console.log(
    `[ImageFinder] Searching images for notebook: ${notebookModel}`
  );

  try {
    // Buscar imagem do notebook
    const notebookImage = await findImageViaSearch(
      `${notebookModel} notebook laptop official`
    );

    // Buscar imagens das peças em paralelo
    const pieceImagePromises = piecesNames.map((pieceName) =>
      findImageViaSearch(`${pieceName} notebook part component`)
    );
    const pieceImages = await Promise.all(pieceImagePromises);

    const pieceImagesMap = piecesNames.reduce(
      (acc, pieceName, index) => {
        acc[pieceName] = pieceImages[index];
        return acc;
      },
      {} as Record<string, string>
    );

    return {
      notebook_image: notebookImage,
      piece_images: pieceImagesMap,
    };
  } catch (error) {
    console.error("[ImageFinder] Error finding images:", error);
    return {
      notebook_image: `https://via.placeholder.com/400x300/1A2B44/32CD32?text=${encodeURIComponent(
        notebookModel
      )}`,
      piece_images: piecesNames.reduce(
        (acc, piece) => {
          acc[piece] = `https://via.placeholder.com/200x150/1A2B44/32CD32?text=${encodeURIComponent(
            piece
          )}`;
          return acc;
        },
        {} as Record<string, string>
      ),
    };
  }
}

/**
 * Busca uma imagem via pesquisa inteligente
 * Retorna URLs de sites confiáveis (Amazon, Wikipedia, sites oficiais)
 */
async function findImageViaSearch(searchQuery: string): Promise<string> {
  try {
    const prompt = `Você é um especialista em encontrar imagens de produtos de tecnologia.

Busque uma imagem de alta qualidade para: "${searchQuery}"

IMPORTANTE:
- Retorne APENAS uma URL de imagem válida e acessível
- Prefira URLs de sites confiáveis: Amazon (.jpg da Amazon), Wikipedia, sites oficiais de fabricantes
- A URL deve terminar com .jpg, .jpeg, .png ou .webp
- NÃO retorne URLs do Google Images diretamente
- Exemplo de URL válida: https://m.media-amazon.com/images/I/71abc123.jpg

Retorne APENAS a URL, sem explicações.`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "Você é um especialista em encontrar URLs de imagens válidas. Retorne APENAS a URL da imagem, sem explicações.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    if (response.choices[0].message.content) {
      const content = response.choices[0].message.content;
      if (typeof content === "string") {
        // Extrair URL da resposta
        const urlMatch = content.match(
          /https?:\/\/[^\s\)\"\'<>]+\.(jpg|jpeg|png|webp)/i
        );
        if (urlMatch) {
          const imageUrl = urlMatch[0];
          console.log(`[ImageFinder] Found image: ${imageUrl}`);
          return imageUrl;
        }
      }
    }

    // Fallback para placeholder
    return `https://via.placeholder.com/300x200/1A2B44/32CD32?text=${encodeURIComponent(
      searchQuery.substring(0, 30)
    )}`;
  } catch (error) {
    console.error(`[ImageFinder] Error finding image:`, error);
    return `https://via.placeholder.com/300x200/1A2B44/32CD32?text=${encodeURIComponent(
      searchQuery.substring(0, 30)
    )}`;
  }
}

/**
 * Gera links de busca com validação FLEXÍVEL e preço médio para cada fornecedor
 * SÓ marca como "Não disponível" quando REALMENTE não encontrar NADA
 */
export async function findSearchLinksWithAveragePrices(
  pieces: Array<{
    nome_peca: string;
    part_number: string;
    especificacao: string;
  }>
): Promise<
  Array<{
    pieceName: string;
    links: SearchLink[];
  }>
> {
  console.log(
    `[LinkFinder] Searching links for ${pieces.length} pieces with FLEXIBLE validation`
  );

  // Buscar links para todas as peças em paralelo
  const promises = pieces.map((piece) =>
    findSearchLinksForProduct(
      piece.nome_peca,
      piece.part_number,
      piece.especificacao
    ).then((links) => ({
      pieceName: piece.nome_peca,
      links,
    }))
  );

  try {
    const results = await Promise.all(promises);
    console.log("[LinkFinder] All searches completed");
    return results;
  } catch (error) {
    console.error("[LinkFinder] Error in search:", error);
    return pieces.map((piece) => ({
      pieceName: piece.nome_peca,
      links: [],
    }));
  }
}

/**
 * Busca links de busca para um produto específico com validação FLEXÍVEL
 * Aceita produtos compatíveis, não apenas o part number exato
 */
async function findSearchLinksForProduct(
  pieceName: string,
  partNumber: string,
  specification: string
): Promise<SearchLink[]> {
  console.log(`[LinkFinder] Searching: ${pieceName} (${partNumber})`);

  const prompt = `Você é um especialista em e-commerce brasileiro e precisa encontrar produtos COMPATÍVEIS.

Produto solicitado:
- Nome: ${pieceName}
- Part Number: ${partNumber}
- Especificação: ${specification}

INSTRUÇÕES IMPORTANTES:
1. SEJA FLEXÍVEL: Aceite produtos COMPATÍVEIS, não apenas o part number exato
2. SÓ marque "Não encontrado" se REALMENTE não existir NENHUM produto similar/compatível
3. Para CADA fornecedor (Mercado Livre, Amazon Brasil, AliExpress, Shopee, Kabum, TerabyteShop):
   - Se encontrar produto compatível: retorne URL de BUSCA e MÉDIA DE PREÇO
   - Se NÃO encontrar NADA: retorne "Não encontrado"

FORMATO DAS URLs DE BUSCA:
- Mercado Livre: https://lista.mercadolivre.com.br/[termo-de-busca]
- Amazon: https://www.amazon.com.br/s?k=[termo-de-busca]
- AliExpress: https://pt.aliexpress.com/wholesale?SearchText=[termo]
- Shopee: https://shopee.com.br/search?keyword=[termo]
- Kabum: https://www.kabum.com.br/busca/[termo]
- TerabyteShop: https://www.terabyteshop.com.br/busca?str=[termo]

EXEMPLO DE RESPOSTA (JSON):
[
  {
    "fornecedor": "Mercado Livre",
    "preco_medio": "R$ 299,90",
    "url_busca": "https://lista.mercadolivre.com.br/bateria-notebook-lenovo",
    "disponibilidade": "Em estoque"
  },
  {
    "fornecedor": "Kabum",
    "preco_medio": "Não encontrado",
    "url_busca": "",
    "disponibilidade": "Não disponível"
  }
]

Retorne APENAS JSON válido, sem explicações.`;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "Você é um especialista em e-commerce que ACEITA PRODUTOS COMPATÍVEIS. Retorne APENAS JSON válido. Seja FLEXÍVEL na busca.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    const content = response.choices[0].message.content;
    if (typeof content === "string") {
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        const links = JSON.parse(jsonMatch[0]);
        console.log(
          `[LinkFinder] Found ${links.length} links for ${pieceName}`
        );
        return links;
      }
    }

    return [];
  } catch (error) {
    console.error(`[LinkFinder] Error searching for ${pieceName}:`, error);
    return [];
  }
}
