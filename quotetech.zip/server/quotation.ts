import { invokeLLM } from "./_core/llm";
import {
  findNotebookAndPieceImages,
  findSearchLinksWithAveragePrices,
} from "./imageAndLinkFinder";

interface NotebookSpecs {
  marca: string;
  modelo: string;
  processador: string;
  gpu: string;
  ram: string;
  armazenamento: string;
  tela: string;
  bateria: string;
  peso: string;
  ano_lancamento: string;
  observacoes: string;
}

interface PecaCompativel {
  nome_peca: string;
  part_number: string;
  tipo: string;
  especificacao: string;
  compatibilidade: string;
}

interface FornecedorPreco {
  fornecedor: string;
  preco_medio: string;
  url_busca: string;
  disponibilidade: string;
}

interface PecaComPrecos {
  nome_peca: string;
  part_number: string;
  tipo: string;
  especificacao: string;
  preco_medio: string;
  links_fornecedores: FornecedorPreco[];
  imagem_peca?: string;
}

/**
 * Identifica o notebook exato baseado no modelo ou S/N usando IA
 */
export async function identifyNotebook(
  modeloOuSerialNumber: string
): Promise<NotebookSpecs> {
  const prompt = `Você é um especialista em notebooks. Analise o seguinte modelo ou número de série e retorne as especificações EXATAS do notebook em formato JSON.

Entrada: "${modeloOuSerialNumber}"

Retorne um JSON com EXATAMENTE estas chaves (sem campos extras):
{
  "marca": "nome da marca (Dell, HP, Lenovo, etc)",
  "modelo": "modelo exato",
  "processador": "processador exato (ex: Intel Core i7-11800H)",
  "gpu": "placa de vídeo exata (ex: NVIDIA RTX 3060)",
  "ram": "memória RAM (ex: 16GB DDR4)",
  "armazenamento": "tipo e capacidade (ex: 512GB SSD NVMe)",
  "tela": "tamanho e especificações (ex: 15.6 polegadas FHD 120Hz)",
  "bateria": "capacidade (ex: 56Wh)",
  "peso": "peso aproximado (ex: 2.3kg)",
  "ano_lancamento": "ano de lançamento",
  "observacoes": "observações importantes sobre manutenção"
}

Seja preciso e use informações reais conhecidas sobre este modelo.`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content:
          "Você é um especialista em notebooks e componentes de computadores. Retorne sempre respostas em JSON válido.",
      },
      {
        role: "user",
        content: prompt,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "notebook_specs",
        strict: true,
        schema: {
          type: "object",
          properties: {
            marca: { type: "string" },
            modelo: { type: "string" },
            processador: { type: "string" },
            gpu: { type: "string" },
            ram: { type: "string" },
            armazenamento: { type: "string" },
            tela: { type: "string" },
            bateria: { type: "string" },
            peso: { type: "string" },
            ano_lancamento: { type: "string" },
            observacoes: { type: "string" },
          },
          required: [
            "marca",
            "modelo",
            "processador",
            "gpu",
            "ram",
            "armazenamento",
            "tela",
            "bateria",
            "peso",
            "ano_lancamento",
            "observacoes",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  try {
    const content = response.choices[0].message.content;
    if (typeof content === "string") {
      return JSON.parse(content) as NotebookSpecs;
    }
    throw new Error("Invalid response format");
  } catch (error) {
    console.error("Failed to parse notebook specs:", error);
    throw new Error("Falha ao identificar o notebook. Tente novamente.");
  }
}

/**
 * Identifica peças compatíveis com o notebook usando IA
 */
export async function identifyCompatibleParts(
  notebookSpecs: NotebookSpecs
): Promise<PecaCompativel[]> {
  const specsJson = JSON.stringify(notebookSpecs, null, 2);

  const prompt = `Você é um especialista em peças de notebooks. Baseado nas especificações do notebook abaixo, identifique as peças principais que podem ser substituídas ou atualizadas.

Especificações do Notebook:
${specsJson}

Retorne um JSON com um array de peças compatíveis. Cada peça deve ter EXATAMENTE estas chaves:
[
  {
    "nome_peca": "nome da peça (ex: Tela LCD 15.6 FHD)",
    "part_number": "número da peça original (ex: NV156FHM-N4G)",
    "tipo": "tipo de peça (ex: Tela, Bateria, Teclado, SSD, RAM)",
    "especificacao": "especificação técnica (ex: 15.6 polegadas FHD 120Hz)",
    "compatibilidade": "descrição de compatibilidade"
  }
]

Inclua as peças mais comuns: Tela, Bateria, Teclado, SSD, RAM, Ventilador.
Seja preciso com números de peça originais.`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content:
          "Você é um especialista em componentes de notebooks. Retorne sempre respostas em JSON válido.",
      },
      {
        role: "user",
        content: prompt,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "compatible_parts",
        strict: true,
        schema: {
          type: "array",
          items: {
            type: "object",
            properties: {
              nome_peca: { type: "string" },
              part_number: { type: "string" },
              tipo: { type: "string" },
              especificacao: { type: "string" },
              compatibilidade: { type: "string" },
            },
            required: [
              "nome_peca",
              "part_number",
              "tipo",
              "especificacao",
              "compatibilidade",
            ],
            additionalProperties: false,
          },
        },
      },
    },
  });

  try {
    const content = response.choices[0].message.content;
    if (typeof content === "string") {
      return JSON.parse(content);
    }
    return [];
  } catch (error) {
    console.error("Failed to parse compatible parts:", error);
    return [];
  }
}

/**
 * Busca preços reais das peças usando IA para gerar queries de busca
 * e retorna links reais de e-commerce
 */
export async function searchPartPrices(
  pecas: PecaCompativel[]
): Promise<PecaComPrecos[]> {
  const prompt = `Você é um especialista em buscar peças de notebooks em lojas online brasileiras.

Para cada peça abaixo, retorne informações de onde comprar com preços REAIS e links REAIS:

Peças:
${JSON.stringify(pecas, null, 2)}

Retorne um JSON com este EXATO formato:
[
  {
    "nome_peca": "nome da peça",
    "part_number": "número da peça",
    "tipo": "tipo",
    "especificacao": "especificação",
    "preco_medio": "preço médio em reais (ex: R$ 510,00)",
    "links_fornecedores": [
      {
        "fornecedor": "nome do fornecedor (Mercado Livre, Amazon, AliExpress, Shopee, etc)",
        "preco": "preço exato (ex: R$ 499,90)",
        "url": "URL REAL do produto na loja (deve ser um link válido e acessível)",
        "disponibilidade": "Em estoque / Fora de estoque / Sob encomenda"
      }
    ]
  }
]

IMPORTANTE:
- Os URLs devem ser REAIS e funcionais
- Use URLs conhecidas de lojas brasileiras
- Inclua pelo menos 2-3 fornecedores por peça
- Preços devem ser realistas para o mercado brasileiro
- Se não souber um preço exato, use uma estimativa realista`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content:
          "Você é um especialista em e-commerce brasileiro e preços de componentes. Retorne sempre URLs reais e funcionais. Responda em JSON válido.",
      },
      {
        role: "user",
        content: prompt,
      },
    ],
  });

  try {
    const content = response.choices[0].message.content;
    if (typeof content === "string") {
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      return JSON.parse(content);
    }
    return [];
  } catch (error) {
    console.error("Failed to parse part prices:", error);
    return [];
  }
}

/**
 * Busca links precisos de produtos em paralelo com imagens
 */
export async function searchPreciseProductLinks(
  pecas: PecaCompativel[]
): Promise<PecaComPrecos[]> {
  console.log("[Quotation] Searching product search links with average prices...");

  const searchLinksData = await findSearchLinksWithAveragePrices(
    pecas.map((p) => ({
      nome_peca: p.nome_peca,
      part_number: p.part_number,
      especificacao: p.especificacao,
    }))
  );

  return pecas.map((peca) => {
    const searchLinks = searchLinksData.find(
      (p: any) => p.pieceName === peca.nome_peca
    );
    return {
      nome_peca: peca.nome_peca,
      part_number: peca.part_number,
      tipo: peca.tipo,
      especificacao: peca.especificacao,
      preco_medio: searchLinks?.links[0]?.preco_medio || "Consultando...",
      links_fornecedores: (searchLinks?.links || []).map((link: any) => ({
        fornecedor: link.fornecedor,
        preco_medio: link.preco_medio,
        url_busca: link.url_busca,
        disponibilidade: link.disponibilidade,
      })),
    };
  });
}

/**
 * Calcula análise de manutenção baseada nas especificações
 */
export async function analyzeMaintenanceNeeds(
  notebookSpecs: NotebookSpecs
): Promise<{
  dificuldade_reparo: string;
  tempo_reparo_estimado: string;
  valor_mao_de_obra_sugerido: string;
  observacoes: string;
}> {
  const prompt = `Você é um técnico especialista em notebooks. Analise o notebook abaixo e forneça uma análise de manutenção.

Especificações:
${JSON.stringify(notebookSpecs, null, 2)}

Retorne um JSON com EXATAMENTE estas chaves:
{
  "dificuldade_reparo": "Fácil / Médio / Difícil / Muito Difícil",
  "tempo_reparo_estimado": "tempo estimado (ex: 1.5 horas)",
  "valor_mao_de_obra_sugerido": "faixa de preço (ex: R$ 150,00 - R$ 200,00)",
  "observacoes": "observações técnicas importantes"
}`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content:
          "Você é um técnico especialista em notebooks. Retorne sempre respostas em JSON válido.",
      },
      {
        role: "user",
        content: prompt,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "maintenance_analysis",
        strict: true,
        schema: {
          type: "object",
          properties: {
            dificuldade_reparo: { type: "string" },
            tempo_reparo_estimado: { type: "string" },
            valor_mao_de_obra_sugerido: { type: "string" },
            observacoes: { type: "string" },
          },
          required: [
            "dificuldade_reparo",
            "tempo_reparo_estimado",
            "valor_mao_de_obra_sugerido",
            "observacoes",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  try {
    const content = response.choices[0].message.content;
    if (typeof content === "string") {
      return JSON.parse(content);
    }
    return content as any;
  } catch (error) {
    console.error("Failed to parse maintenance analysis:", error);
    return {
      dificuldade_reparo: "Médio",
      tempo_reparo_estimado: "2 horas",
      valor_mao_de_obra_sugerido: "R$ 200,00 - R$ 300,00",
      observacoes: "Consulte um técnico especializado",
    };
  }
}

/**
 * Busca imagens de notebook e peças
 */
export async function getNotebookAndPieceImages(
  notebookModel: string,
  piecesNames: string[]
) {
  console.log("[Quotation] Fetching images for notebook and pieces...");
  try {
    return await findNotebookAndPieceImages(notebookModel, piecesNames);
  } catch (error) {
    console.error("Failed to fetch images:", error);
    return {
      notebook_image: `https://via.placeholder.com/400x300?text=${encodeURIComponent(
        notebookModel
      )}`,
      piece_images: {},
    };
  }
}
