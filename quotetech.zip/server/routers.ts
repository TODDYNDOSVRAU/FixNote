import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  identifyNotebook,
  identifyCompatibleParts,
  analyzeMaintenanceNeeds,
  searchPreciseProductLinks,
  getNotebookAndPieceImages,
} from "./quotation";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  quotation: router({
    search: publicProcedure
      .input(
        z.object({
          modeloOuSerialNumber: z
            .string()
            .min(2, "Digite um modelo ou S/N válido"),
        })
      )
      .mutation(async ({ input }) => {
        try {
          console.log(
            `[Quotation] Starting search for: ${input.modeloOuSerialNumber}`
          );

          // Step 1: Identify notebook specs
          console.log("[Quotation] Identifying notebook...");
          const notebookSpecs = await identifyNotebook(
            input.modeloOuSerialNumber
          );
          console.log(
            `[Quotation] Notebook identified: ${notebookSpecs.marca} ${notebookSpecs.modelo}`
          );

          // Step 2: Identify compatible parts
          console.log("[Quotation] Identifying compatible parts...");
          const compatibleParts = await identifyCompatibleParts(notebookSpecs);
          console.log(
            `[Quotation] Found ${compatibleParts.length} compatible parts`
          );

          // Step 3: Get images and search precise links in parallel
          console.log("[Quotation] Fetching images and searching links...");
          const imagesPromise = getNotebookAndPieceImages(
            `${notebookSpecs.marca} ${notebookSpecs.modelo}`,
            compatibleParts.map((p) => p.nome_peca)
          );

          const preciseLinksPromise =
            searchPreciseProductLinks(compatibleParts);

          // Step 4: Analyze maintenance
          console.log("[Quotation] Analyzing maintenance needs...");
          const maintenanceAnalysis = await analyzeMaintenanceNeeds(
            notebookSpecs
          );

          // Wait for parallel operations
          const [imagesData, pecasComLinks] = await Promise.all([
            imagesPromise,
            preciseLinksPromise,
          ]);

          console.log("[Quotation] All data collected, returning results");

          return {
            modelo_identificado: `${notebookSpecs.marca} ${notebookSpecs.modelo}`,
            imagem_modelo_url: imagesData.notebook_image,
            especificacoes_completas: {
              processador: notebookSpecs.processador,
              gpu: notebookSpecs.gpu,
              ram: notebookSpecs.ram,
              armazenamento: notebookSpecs.armazenamento,
              tela: notebookSpecs.tela,
              bateria: notebookSpecs.bateria,
            },
            dificuldade_reparo: maintenanceAnalysis.dificuldade_reparo,
            tempo_estimado: maintenanceAnalysis.tempo_reparo_estimado,
            valor_mao_de_obra_sugerido:
              maintenanceAnalysis.valor_mao_de_obra_sugerido,
            observacoes: maintenanceAnalysis.observacoes,
            pecas_encontradas: pecasComLinks.map((peca) => ({
              ...peca,
              imagem_peca: imagesData.piece_images[peca.nome_peca] || undefined,
            })),
          };
        } catch (error) {
          console.error("[Quotation] Error:", error);
          throw new Error(
            `Erro ao buscar cotação: ${
              error instanceof Error ? error.message : "Erro desconhecido"
            }`
          );
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
